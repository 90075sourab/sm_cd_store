const movieModel=require('../models/movie');
const path=require('path');
const fs=require('fs');

const raw_basename=__dirname.split(path.sep);
raw_basename.pop();
const basename=raw_basename.join(path.sep);

class myError extends Error{
    constructor(name,message,type)
    {  super(message)
        this.name=name;
        this.message=message;
        this.type=type;
    }
}




module.exports=(req,res)=>{

    const mid=req.body.mid;
    const filename=req.file.filename;
    const query=movieModel.findByIdAndUpdate(mid,{image:filename})
   
    query.exec((err,data)=>{
    try{
    if(err){
        
        //fs.unlinkSync(basename+"/public/uploads/"+filename);
        //res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Upload Image file"});
        throw new myError('file',basename+"/public/uploads/"+filename,1);
        
    }else{
        if(data==null){
            //fs.unlinkSync(basename+"/public/uploads/"+filename);
            //res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Upload Image file"});
            throw new myError('file',basename+"/public/uploads/"+filename,1);
            
            
        }else{
            if(data.image!='default.jpg'){
            
            //fs.unlinkSync(basename+"/public/uploads/"+data.image)
            res.render("admin-msg",{msgTitle:'Success',msgText:"Movie Image Updated"});
            //throw new Error(basename+"/public/uploads/"+data.image);
            throw new myError('file',basename+"/public/uploads/"+data.image,2);
            }
            else{
                
                res.render("admin-msg",{msgTitle:'Success',msgText:"Movie Image Uploaded Successfully"});
            }
    
        }
    }
    
}catch(e){
    try{
        if(e.name='file')
           fs.unlinkSync(e.message);
        if(e.type==1)
           res.render('adminupload',{msgTitle:"Error",msgText:"Can not Upload Image file"})
    }catch(e){
        console.log('warning file path wrong or file missing');
        res.render('adminupload',{msgTitle:"Error",msgText:"Can not Upload Image file"})
        //res.redirect('adminupload',{msgTitle:"Error",msgText:"Can not Upload Image file"})
    }
}
    
    });






};