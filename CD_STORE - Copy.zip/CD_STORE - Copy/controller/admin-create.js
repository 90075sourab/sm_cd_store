const movieModel=require('../models/movie');





module.exports=(req,res)=>{
    const m_name=req.body.m_name;
    const m_rdate=req.body.m_rdate;
    const m_film=req.body.m_film!=''?req.body.m_film:null;
    const m_production=req.body.m_production!=''?req.body.m_production:null;;
    const m_lang=req.body.m_lang!=''?req.body.m_lang:null;;
    const m_tag=req.body.m_tag!=''?req.body.m_tag.split(','):null;
    const m_actor=req.body.m_actor!=''?req.body.m_actor.split(','):null;
    const m_desc=req.body.m_desc!=''?req.body.m_desc:null;
    //m_desc=req.body.m_desc
    const m_price=req.body.m_price;//price field no problem//
    const m_hour=req.body.m_hour;
    const userId=req.userId;
    //console.log("tag",m_tag)
    //console.log(m_tag,m_actor);
    
    
    const movieData=new movieModel({

        //here 9 field will insert by admin or owner
       name:m_name,
       film:m_film,
       production:m_production,
       language:m_lang,
       release:m_rdate,
       tag:m_tag,
       actor:m_actor,
       description:m_desc,
       price:m_price,
       hour:m_hour,
       uid:userId,
       




    
    });
    
    movieData.save(function(err,data){
    if(err){
        res.render("admin-msg",{msgTitle:"Error",msgText:"Movies Can not Save"});
    }else{
        res.render("admin-msg",{msgTitle:"Success",msgText:"Movies Saved"});
    }


    });
        




};