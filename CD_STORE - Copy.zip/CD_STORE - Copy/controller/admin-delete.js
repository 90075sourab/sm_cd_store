
const movieModel=require('../models/movie');

const path=require('path');
const fs=require('fs');

const raw_basename=__dirname.split(path.sep);
raw_basename.pop();
const basename=raw_basename.join(path.sep);

module.exports=(req,res)=>{

    const mid=req.params.mid;
    const query=movieModel.findByIdAndDelete(mid);
    query.exec((err,data)=>{
        
        if(err){
            //console.log("movie Delete db Error");
            res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Delete"})
        }else{
            if(data==null)
            {//console.log("movie in this id Error");
             res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Delete"});
        }
            else{
                const filename=data.image;
               try{ fs.unlinkSync(basename+"/public/uploads/"+filename);
            }catch(e){
                console.log('Error file delete')
            }


                res.render("admin-msg",{msgTitle:"Success",msgText:"Movie Deleted Successfully"});
            }

        }
        

    });


}