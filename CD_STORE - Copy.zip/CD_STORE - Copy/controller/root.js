
const createMovie=require('./admin-create');
const tableMovie=require('./admin-table');
const findMovie=require('./admin-find');
const previewMovie=require('./admin-preview');
const editMovie=require('./admin-edit');
const uploadMovie=require('./admin-upload');
const deleteMovie=require('./admin-delete');
module.exports={
    createMovie:createMovie,
    tableMovie:tableMovie,
    findMovie:findMovie,
    previewMovie:previewMovie,
    editMovie:editMovie,
    uploadMovie:uploadMovie,
    deleteMovie:deleteMovie,
}