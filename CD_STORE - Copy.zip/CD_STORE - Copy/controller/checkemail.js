

hasEmail={

email:'',
userModel=require("../models/user");

checkDatabase=()=>{
const query=this.userModel.find({useremail:this.email})
result=query.exec();
console.log(result);


}





}
module.export=hasEmail;