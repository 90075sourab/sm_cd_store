const movieModel=require('../models/movie');


module.exports=(req,res)=>{
   
    const mid=req.body.mid;
    const m_name=req.body.m_name;
    const m_rdate=req.body.m_rdate;
    const m_film=req.body.m_film!=''?req.body.m_film:null;
    const m_production=req.body.m_production!=''?req.body.m_production:null;;
    const m_lang=req.body.m_lang!=''?req.body.m_lang:null;;
    const m_tag=req.body.m_tag!=''?req.body.m_tag.split(','):null;
    const m_actor=req.body.m_actor!=''?req.body.m_actor.split(','):null;
    const m_desc=req.body.m_desc!=''?req.body.m_desc:null;
    const m_price=req.body.m_price;//price field no problem//
    const m_hour=req.body.m_hour;

    const query=movieModel.findByIdAndUpdate(mid,{
       
           name:m_name,
           film:m_film,
           production:m_production,
           language:m_lang,
           release:m_rdate,
           tag:m_tag,
           actor:m_actor,
           description:m_desc,
           price:m_price,
           hour:m_hour,
    
    });
    
    query.exec((err,data)=>{
        if(err){
            //console.log("Error in Update");
            res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Update"});
        }else{
            if(data==null){
                //console.log("Update this id null");
                res.render("admin-msg",{msgTitle:"Error",msgText:"Can not Update"});
            }else{
                res.render("admin-msg",{msgTitle:"Success",msgText:"Updated Successfully"});
                //console.log("update successfull");
            }
        }
        //res.redirect("/admintable");
    
    
    
    
    });
    


}