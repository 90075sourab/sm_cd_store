
const movieModel=require('../models/movie');
module.exports=(req,res)=>{



const alldoc=movieModel.find();
alldoc.exec((err,data)=>{
    if(err){
        res.render("admin-msg",{msgTitle:"Error",msgText:"Movies Not Found"});
    }else{
        if(data==null){

        res.render("admin-msg",{msgTitle:"Error",msgText:"Movies not Found"});
        }
        else{
            //console.log(data.movie);
            //console.log(data);
            res.render("admin-table",{movieDetails:data});
        }
    }
});





}