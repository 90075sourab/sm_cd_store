const mongoose=require("mongoose");
const URL="mongodb://localhost/cdstore";
mongoose.connect(URL,{useNewUrlParser:true,useUnifiedTopology:true,useFindAndModify:false,useCreateIndex:true});
const conn=mongoose.connection;
conn.on("open",(err)=>{console.log("database connected")});
//console.log("hola")
module.exports=conn;
