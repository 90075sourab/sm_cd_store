const mongoose=require("mongoose");
const { model } = require("mongoose");

const userSchema=mongoose.Schema({
    username:{
        type:String,
        required:true,
    },
    useremail:{type:String,
    required:true,
    
      },
    password:{
        type:String,
        required:true,
        
    },
    role:{
        type:String,
        default:'restricted'
    },
    salt:{
        type:String,
        required:true,
    },
    dateCreated:{
        type:Date,
        required:true,
    }
});

module.exports=mongoose.model("users",userSchema,"users");
