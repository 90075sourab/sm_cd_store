const mongoose=require('mongoose');

movieSchema=mongoose.Schema({
    name:{
        type:String ,  //1
        required:true,
    },
    price:{
        type:Number,
        default:0,
    },
    release:{
        type:Date,   //2
    },
    film:{ //like hollywood
        type:String   //3 
        
    },
    production:{
        type:String, //4
       
    },
    language:{
        type:String   //5
    },
    description:{
        type:String, //6
       // default:'',
      // required:true,

    },
    actor:{
        type:[String], //7
        
    },
    tag:{
        type:[String],  //8
       
    },
    hour:{
     type:Number,
     default:1,
    },

    click:{ //bellow all  input from visitors
        type:Number,  //9
        default:0,
    },
    like:{
        type:Number, //10
        default:0,

    }
    ,view:{
        type:Number, //11
        default:0,

    },
    image:{
        type:String,
        default:'default.jpg',
    },
    

})


module.exports=mongoose.model('movies',movieSchema,'movies');
