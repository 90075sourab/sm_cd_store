const express=require("express");
const bodyParser=require("body-parser");
const cookieParser=require('cookie-parser');
const app=express();
const loginRoute=require("./routes/login");
const registerRoute=require("./routes/register");
const userRoute=require("./routes/user");
const createnewRouter=require("./routes/createnew");
const editRouter=require("./routes/admin-edit");
const previewRouter=require("./routes/admin-preview")

const admin_table_router=require("./routes/admin-table");
const deleteRoute=require("./routes/admin-delete");
const uploadRoute=require("./routes/admin-upload");
const conn=require("./models/connection");
const jwtAuthenticate=require("./middleware/jwtAuthenticate");
const jwtAdminAuth=require("./middleware/jwtAdminAuth");


app.use(cookieParser());
app.use(express.static("public"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}))
app.set('view engine','ejs');
app.get("/",(req,res)=>{

    res.redirect("/login");

});


app.use("/login",loginRoute);
app.use("/register",registerRoute);
app.use(jwtAuthenticate.verify);
app.use("/user",userRoute);
app.use(jwtAdminAuth.verify);
app.use("/createnew",createnewRouter);
app.use("/admintable",admin_table_router);

app.use("/adminpreview",previewRouter);
app.use("/admindelete",deleteRoute);
app.use("/adminupload",uploadRoute);
app.use("/adminedit",editRouter);
app.listen(8000,(err)=>console.log("server is running"));