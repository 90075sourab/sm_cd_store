const crypto=require("crypto");

getRandomBytes=(length=1)=>{
const rb=crypto.randomBytes(Math.ceil(length/2));
return rb.toString('hex').slice(0,length);
}

//getRandomBytes(10);



getHash=(password,salt)=>{
    const algo="sha512";
    hash=crypto.createHmac(algo,salt);
    hash.update(password);
    var value=hash.digest('hex');
    //console.log(hash)
    return value;


}
/*
p={
    genSalt:getRandomBytes,

   genHash:getHash,
}
*/


hashMatch=(f_password,f_salt,m_password)=>{
    if(f_password!=''&&f_salt!=''&&m_password!='')
    {   
        hash_password=getHash(m_password,f_salt);
    return hash_password==f_password;
    }else{
    console.log(f_password,f_salt,m_password);
    throw new Error("required parameter three");
    }
    



}

module.exports={
    genSalt:getRandomBytes,
    genHash:getHash,
    hashMatch:hashMatch,
}

/*
s=p.genSalt(10)
a=p.genHash("myluck",s)
console.log(a)
*/

