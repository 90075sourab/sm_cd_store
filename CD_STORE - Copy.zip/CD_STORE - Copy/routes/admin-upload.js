const express=require("express");
const router=express.Router();
const multer=require("multer");

const PATH="./public/uploads";
const movieController=require("../controller/root");
const uploadAuth=require("../controller/uploadAuth");
const Storage=multer.diskStorage({
    destination:(res,file,cb)=>{
        cb(null,PATH);

    },
    filename:(res,file,cb)=>{
        cb(null,file.fieldname+"-"+Date.now()+file.originalname);

    },
    
});

const upload=multer({
    storage:Storage,
    fileFilter:(req,file,cb)=>{
    const fileFormats=['image/jpg','image/jpeg','image/png']
    const mime=file.mimetype;
    if(fileFormats.indexOf(mime)!=-1){
        //console.log("match format");
        cb(null,true)
    }else{
        console.log("not match format",file);
        cb(null,false);
    }
    //}

},
limits:{
    fileSize:1012*150,
    files:1,
}

});

function m1(req,res,next){
    console.log(req.body);
    next();
}

router.get('/:mid/:msg?',(req,res)=>{
   
    const mid=req.params.mid;
    const msg=req.params.msg;
    res.render("admin-upload",{movieId:mid,errorMsg:msg});

});


router.post("/",upload.single('movieFile'),(req,res,next)=>{
const mid=req.body.mid;
const msg="Enter a Valid Image"
    if(req.file!=undefined){
        
        //console.log(req.file);
        next('route');
        
    }
    else{
        
        console.log("next error");
        res.render("admin-upload",{movieId:mid,errorMsg:msg});
        
       
    }
 
    
   
   
});


router.post("/",movieController.uploadMovie);




/*
router.post('/',upload.single('movieFile'),(req,res)=>{


    if(req.file!=undefined){

        console.log("file got");
        res.send("upload",file);

    }else{
       console.log("file not found");
       res.redirect("back");    
    
    }





})

*/



module.exports=router;