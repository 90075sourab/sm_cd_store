const express=require("express");
const router=express.Router();
const jwtAuthenticate=require("../middleware/jwtAuthenticate");
//const userModel=require("../models/user");


router.get("/",(req,res)=>{

res.render("user");

});

module.exports=router;