const express=require("express");
const router=express.Router();
const userModel=require("../models/user");
const myHash=require("../hash/script");
const jwt=require('jsonwebtoken');
const secretKey=require('../middleware/secret');
router.get("/",(req,res)=>{

res.render("login");

});


router.post("/",(req,res)=>{

    req_useremail=req.body.useremail;
    req_password=req.body.password;
    const query=userModel.findOne({useremail:req_useremail});
    query.exec((err,data)=>{
        if(err){
            res.send("Can not Login Your Account")

        }else{
            if(data==null){
                res.render("login",{err:{title:"Warning",msg:"Wrong Email Id"}})

            }else{//this block chek for password *start
               
                f_password=data.password;
                f_salt=data.salt;
                if(!myHash.hashMatch(f_password,f_salt,req_password)){
                    res.render("login",{err:{title:"Warning",msg:"Wrong Password"}})

                }else{//final goal start
                    
                    accessToken=jwt.sign({uid:data._id,username:data.username,role:data.role},secretKey.get());
                    res.clearCookie('token');
                    res.cookie('token',accessToken);
                    data.role!='restricted'?res.redirect('/admintable'):res.redirect("/user");
                    

                }//final goal end
                




            }//this block chek for password *start

        }
       

    })
    

    //res.send(useremail+password);



})

module.exports=router

