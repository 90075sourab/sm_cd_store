const express=require("express");

const router=express.Router();
const movieController=require("../controller/root");

router.get('/:mid',movieController.findMovie);

router.post('/',movieController.editMovie);

module.exports=router;