const express=require('express');
const router=express.Router();

const movieController=require("../controller/root");



router.get('/',(req,res)=>{

    //console.log(req.userId);
    res.render("createnew");
});


router.post('/',movieController.createMovie);
module.exports=router