const express=require("express");
const router=express.Router();
const movieController=require("../controller/root");
router.get("/:mid",movieController.deleteMovie);

module.exports=router;