const express=require("express");
const userModel=require("../models/user");
const dupEmail=require("../middleware/emailValid");
const myHash=require("../hash/script");
const crypto=require("crypto");
//const hasEmail=require("../validation/hasEmail");
//const user = require("../models/user");
const {check,validationResult}=require("express-validator");
const router=express.Router();

//emailValid.email="so";
//hasEmail=new hasEmailc()


router.get("/",(req,res)=>{
    //console.log(req.headers.authorization);
    //console.log();
    //res.set("authorization","bearer Mother fucker")
    res.render("register");

})

check_un=check("username").not().isEmpty().withMessage("Select a Username")
checkEmail=check("useremail").isEmail().withMessage("Email format is not Right");
check_pwd=check("password").not().isEmpty().withMessage("Select a Password");
check_confrm_pwd=check("confirm_password").custom((value,{req})=>{

    if(value!=req.body.password){
        //console.log("passwords",req.body.password,value)
        throw Error("confirm_password not matching:");
    }

    return true;
})

/*.custom(value=>{
    hasEmail.setEmail(value);
    if(hasEmail.find()==false){//find will return
        throw new Error("Email in use:");
    }else{
        console.log("ok unique")
    }
    return true;
});
*/
/*
hasEmail.setEmail("so@gamil.com");
p=hasEmail.find()
console.log("p",p)
*/
/*
passwordSalt=myHash.genSalt(10);

passwordHash=myHash.genHash(p,passwordSalt)
console.log(passwordHash);
*/
registerValid=[checkEmail,check_un,dupEmail,check_pwd,check_confrm_pwd];
router.post("/",registerValid,async (req,res)=>{

var password=req.body.password;


const valid_error=validationResult(req);
//console.log("body");
if(!valid_error.isEmpty()){
    //console.log(valid_error.errors[0].msg);
    error_message=valid_error.errors[0].msg;
    error_value=valid_error.errors[0].value;

    res.render("register",{err:{title:"Error",msg:error_message}});
    
}else{


    passwordSalt=myHash.genSalt(10);
    passwordHash=myHash.genHash(password,passwordSalt)

    const u1=new userModel({
        username:req.body.username,
        useremail:req.body.useremail,
        password:passwordHash,
        salt:passwordSalt,
        dateCreated:Date.now()
    
    })
    
    u1.save((err,data)=>{
        //console.log(err.errors['password'].message);
    //error=u1.validateSync();
    //console.log("my Error",error);
        
        if(err){
            //console.log(err.message.indexOf("duplicate key error collection"));//how tod error in unique value
            res.render("register",{err:{title:"Error",msg:"Can not Register"}});
            console.log(err);

        }else{

            res.render("register",{err:{title:"Success",msg:"Registered Successfully"}});

        }
        
    
    })

}


//crypto.hash
//res.send("Email brand new");
/*
const error=await validationResult(req);
if(!error.isEmpty()){
    console.log(error);
}else{
    console.log("body",body);    

}

const u1=new userModel({
    username:req.body.username,
    useremail:req.body.useremail,
    password:req.body.password,

})

u1.save((err,data)=>{
    //console.log(err.errors['password'].message);
//error=u1.validateSync();
//console.log("my Error",error);
    
    if(err){
        console.log(err.message.indexOf("duplicate key error collection"));//how tod error in unique value
        res.send("Error Register");
    }else{
        res.send("successfull registered");
    }
    

})
*/

//console.log("body",body);





//res.json(body);
});


module.exports=router;