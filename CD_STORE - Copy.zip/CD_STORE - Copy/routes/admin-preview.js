const express=require("express");
const router=express.Router();
const movieController=require("../controller/root");

router.get("/:mid",movieController.previewMovie);


module.exports=router;