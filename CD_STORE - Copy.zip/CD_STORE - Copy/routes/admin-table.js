const express=require('express');
const router=express.Router();
const movieController=require("../controller/root");

//const movieController=require("../controller/act.movie");



router.get('/',movieController.tableMovie);


//router.post('/',movieController.add);
module.exports=router