

$(document).ready(()=>{
	


//main motive in js of sidenav
//is .sidebar must be remove when window size is greate than 1050
//and when this class is also use less to give when window greater than 1050
$("#menu-btn").click(()=>{

	w=$('html').width();
    if(w<=1050)
	$("#sidebar").toggleClass('sidebar-active');
    setTimeout(()=>{
	$("#sidebar").addClass('sidebar-on');
},1000)
});


$(".wrapper").click(()=>{
	if($("#sidebar").hasClass('sidebar-on')==true){
	   $("#sidebar").removeClass('sidebar-active');
	   setTimeout(()=>{
	$("#sidebar").removeClass('sidebar-on');
},1000)
	}

});



$("#movie-img-file").change(()=>{

	img=document.getElementById("movie-img-file").files[0];
	
	const reader=new FileReader();
	reader.onload=()=>{
		//alert("ok");
		const dataurl=reader.result;
		$("#upload-img").attr('src',dataurl);
	}
	
	reader.readAsDataURL(img);
	
	
	
	});
	$("#movie-img-file").click(()=>{
	img=document.getElementById("movie-img-file").files[0];
	if(img!=undefined){
		$("#upload-img").attr('src','');
	}
	
	});


});