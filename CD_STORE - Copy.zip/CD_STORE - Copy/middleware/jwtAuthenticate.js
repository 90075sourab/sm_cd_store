const jwt=require('jsonwebtoken');
const secretKey=require('./secret');
//const cookieParser = require('cookie-parser');


module.exports.verify=(req,res,next)=>{

const cookies=req.cookies;


try{
    jwt.verify(cookies.token,secretKey.get(),(err,decode)=>{
        if(err)
        {
            //console.log('jwt not verifying');
            throw new Error('can not verify');

        }else{
            req.userId=decode.uid;
            req.username=decode.username;
            req.role=decode.role
            next();

        }
    });
}catch(e){
    //console.log(e);
    res.redirect('/login');
    
}


}