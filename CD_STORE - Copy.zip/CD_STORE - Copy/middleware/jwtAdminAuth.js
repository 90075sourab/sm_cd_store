const jwt=require('jsonwebtoken');
const secretKey=require('./secret');
//const cookieParser = require('cookie-parser');


module.exports.verify=(req,res,next)=>{
if(req.role!=='restricted'){
    next();
}else{
    res.redirect('/user');
}


}