const userModel=require("../models/user");
const { query } = require("express-validator");
module.exports=function(req,res,next){

    const chk_email=req.body.useremail;
    //console.log(chk_email);
    if(chk_email==''){
        res.render("register",{err:{title:"Error",msg:"Email Field Empty"}});;
    }
    try{
        const query=userModel.findOne({useremail:chk_email});
        query.exec((err,data)=>{
            if(err){
                //console.log(err);
                throw new Error("checking email in database Error");
                
            }else{
                if(data!=null){
                    console.log("data",data);
                    res.render("register",{err:{title:"Error",msg:"Email Already in use"}});

                }else{
                    next();
                }
            }


        });

    }
    catch(e){
        console.log("check email in databse",e);
    }




}

