const fs=require('fs');

module.exports.get=()=>{
try{
const secret=fs.readFileSync(__dirname+'/secret.txt')
//console.log(t);
return secret.toString('utf-8')

//secret.toString('utf-8');

}catch(e){
    console.log('secret code reading error');
}

}